# Requisitos do Sistema

## Requisitos Funcionais

| Código | Descrição |
|---|---|
| RF01 | Cadastrar usuários |
| RF02 | Cadastrar livros |
| RF03 | Consultar livros |
| RF04 | Registrar empréstimos |
| RF05 | Registrar devoluções |

## Requisitos Não Funcionais

| Código | Descrição |
|---|---|
| RNF01 | O sistema deverá possuir autenticação |
| RNF02 | O sistema deverá realizar backup |
| RNF03 | A interface deverá ser responsiva |